from django.apps import AppConfig


class CreategoodsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'createGoods'
